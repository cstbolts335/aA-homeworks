class Board
  attr_accessor :cups

  def initialize(name1, name2)
    @name1 = name1
    @name2 = name2
    @cups = Array.new(14) {Array.new()}
  end

  def place_stones
    # helper method to #initialize every non-store cup with four stones each
    @cups.each_with_index do |cup, idx|
     next if idx == 6 || idx == 13
        4.times do
         cup << :stone
        end
    end
  end

  def valid_move?(start_pos)
    raise "Invalid starting cup" if start_pos < 0 || start_pos > 12 || start_pos == 6
    raise "Starting cup is empty" if @cups[start_pos].empty?
  end

  def make_move(start_pos, current_player_name)
    # this is for emptying the cup
    player_start_stones = @cups[start_pos]
    @cups[start_pos] = [] #this is b/c the player is picking up the cups, hence the start positon in empty

    cup_index = start_pos

    until player_start_stones.count == 0
      cup_index = 0 if cup_index > 13

        if cup_index == 6
            @cups[6] << player_start_stones.shift if current_player == @name1
        elsif cup_index == 13
            @cups[13] << player_start_stones.shift if current_player == @name2
        else
          @cups[cup_idx] << player_start_stones.shift
        end
        cup_idx += 1

    end

    render #make this show up on our Board
    next_turn(cup_index)

  end

  def next_turn(ending_cup_idx)
    # helper method to determine whether #make_move returns :switch, :prompt, or ending_cup_idx
    if @cups[ending_cup_idx].length == 1 #why is this 1 and not 0?
      :switch
    elsif ending_cup_idx == 6 || ending_cup_idx == 13
      :prompt
    else
      ending_cup_idx
    end
  end

  end

  def render
    print "      #{@cups[7..12].reverse.map { |cup| cup.count }}      \n"
    puts "#{@cups[13].count} -------------------------- #{@cups[6].count}"
    print "      #{@cups.take(6).map { |cup| cup.count }}      \n"
    puts ""
    puts ""
  end

  def one_side_empty? #need to come back to this
    @cups.take(6).all? { |cup| cup.empty? } ||
    @cups[7..12].all? { |cup| cup.empty? }
  end

  def winner
    player1_count = @cups[6].count
    player2_count = @cups[13].count

      if player1_count == player2_count
        :draw
      else
        player1_count > player2_count ? @name1 : @name2
      end
  end
